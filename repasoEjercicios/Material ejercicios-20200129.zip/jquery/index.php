<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Datos alumnos</title>
</head>
<body>

	<?php
		$conexion = new PDO('mysql:host=localhost;dbname=jquery;charset=UTF8', 'jquery', 'jquery');
		$sql = 'SELECT * FROM alumnos';
		$result = $conexion->query($sql);
	?>

	Alumnos:
	<ul>
	<?php
		while ($alumno = $result->fetchObject()) {
			echo '<li id="alumno'. $alumno->id .'">'. $alumno->nombre .' '. $alumno->apellido1 .' '. $alumno->apellido2 .'</li>';
		}
	?>
	</ul>
	
	<br><br>
	<a href="notas.php">Ver notas</a>
</body>
</html>