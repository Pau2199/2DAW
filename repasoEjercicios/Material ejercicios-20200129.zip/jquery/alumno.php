<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Datos alumnos</title>
</head>
<body>

	<?php
		$conexion = new PDO('mysql:host=localhost;dbname=jquery;charset=UTF8', 'jquery', 'jquery');
		$sql = 'SELECT * FROM alumnos WHERE id='. $_GET['id'] .';';
		$alumno = $conexion->query($sql)->fetchObject();
	?>

	<h1>Datos del alumno</h1>
	<div id='alumno<?=$alumno->id?>'>
		Nombre: <span><?=$alumno->nombre?></span> <span><?=$alumno->apellido1?></span> <span><?=$alumno->apellido2?></span>
		<br>
		DNI: <span><?=$alumno->dni?></span>
		<br>
		Fecha de nacimiento: <span><?=$alumno->fechanacimiento?></span>
		<br>
		Email: <span><?=$alumno->email?></span>
		<br>
		Teléfono: <span><?=$alumno->telefono?></span>
	</div>
	
	<br><br>
	<a href="index.php">volver</a>
</body>
</html>