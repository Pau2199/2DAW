<?php
class Config {
	static public $mvc_bd_hostname = 'localhost';
	static public $mvc_bd_nombre = 'alimentos';
	static public $mvc_bd_usuario = 'root';
	static public $mvc_bd_clave = '';
	static public $mvc_vis_css = 'estilo.css';
}
?>