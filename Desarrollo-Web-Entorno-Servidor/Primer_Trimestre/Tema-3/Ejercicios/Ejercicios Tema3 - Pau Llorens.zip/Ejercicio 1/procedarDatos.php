<?php
    echo 'Datos del Formulario <br>';
    echo 'Codigo: ' . $_REQUEST['codigo']. '<br>';
    echo 'Nombre: ' . $_REQUEST['nombre']. '<br>';
    echo 'Precio: ' . $_REQUEST['precio']. '<br>';
    echo 'Descripcion: '. $_REQUEST['descripcion']. '<br>';
    echo 'Fabricante: '. $_REQUEST['fabricante']. '<br>';
    echo 'Cantidad: ' .$_REQUEST['cantidad']. '<br>';
    echo 'Fecha de Adquisicion: ' .$_REQUEST['fechaAdquisicion'] . '<br>';
?>